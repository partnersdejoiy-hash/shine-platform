import { useState, useEffect, useCallback, createContext, useContext } from "react";
import { api } from "@/hooks/use-api";

interface User {
  id: string;
  _id?: string;
  email: string;
  name: string;
  role?: string;
  avatarUrl?: string;
  image?: string;
  orgId?: string;
  status?: string;
  mustChangePassword?: boolean;
  accentColor?: string;
  notificationPrefs?: any;
  soundPrefs?: any;
  customSoundUrl?: string;
  approvedPermissions?: string[];
  isActive?: boolean;
  [key: string]: any;
}

interface AuthContextType {
  isLoading: boolean;
  isAuthenticated: boolean;
  user: User | null;
  signIn: (...args: any[]) => Promise<any>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  isLoading: true,
  isAuthenticated: false,
  user: null,
  signIn: async () => {},
  signOut: async () => {},
});

export function useAuth() {
  const ctx = useContext(AuthContext);
  const [user, setUser] = useState<User | null>(ctx.user);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (ctx.user) {
      setUser(ctx.user);
      setLoading(false);
      return;
    }
    const token = api.loadTokens();
    if (!token) {
      setLoading(false);
      return;
    }
    api.getMe()
      .then((u: any) => { if (u) u._id = u.id; setUser(u); setLoading(false); })
      .catch(() => { api.clearTokens(); setLoading(false); });
  }, [ctx.user]);

  const signIn = useCallback(async (...args: any[]) => {
    // Support Convex-style: signIn("password", { email, password })
    // Or: signIn("email-otp", formData)
    // Or: signIn("google", { redirectTo })
    // Or simple: signIn(email, password)
    let email: string;
    let password: string;
    if (args[0] === "password" && typeof args[1] === "object") {
      email = args[1].email;
      password = args[1].password;
    } else if (args[0] === "email-otp") {
      const data = args[1];
      email = data?.get?.("email") ?? data?.email ?? "";
      const res = await api.forgotPassword(email);
      return res;
    } else if (args[0] === "google" || args[0] === "github" || args[0] === "microsoft-entra-id" || args[0] === "apple") {
      throw new Error(`SSO not yet available. Use email + password.`);
    } else {
      email = args[0];
      password = args[1];
    }
    const res = await api.login(email, password);
    api.setTokens(res.accessToken, res.refreshToken);
    const u = res.user || res;
    u._id = u.id;
    setUser(u);
  }, []);

  const signOut = useCallback(async () => {
    try { await api.logout(); } catch {}
    api.clearTokens();
    setUser(null);
  }, []);

  return {
    isLoading: loading || ctx.isLoading,
    isAuthenticated: !!user || ctx.isAuthenticated,
    user: user || ctx.user,
    signIn: ctx.signIn || signIn,
    signOut: ctx.signOut || signOut,
  };
}

export { AuthContext };
