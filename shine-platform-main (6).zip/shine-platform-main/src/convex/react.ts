/**
 * Convex React compatibility shim.
 *
 * Provides `useQuery`, `useMutation`, `useAction` that work exactly like
 * their Convex counterparts but route through the self-hosted REST API.
 */
import { useState, useEffect, useCallback, useRef } from "react";
import { api as shineApi } from "@/hooks/use-api";

interface ShimFn {
  _url: string | ((...args: any[]) => string);
  _method: string;
  _body?: (...args: any[]) => any;
  _kind: "query" | "mutation";
}

function resolveUrl(fn: ShimFn, args?: any): string {
  if (typeof fn._url === "function") return fn._url(fn, args);
  return fn._url;
}

function getBody(fn: ShimFn, args: any): any {
  if (fn._body) return fn._body(args);
  return args;
}

/**
 * useQuery — mirrors Convex's reactive query hook.
 * Fetches data on mount and when args change.  Returns `undefined` while loading.
 */
export function useQuery(fn: ShimFn, args?: Record<string, any>, _options?: any): any {
  const [data, setData] = useState<any>(undefined);
  const url = resolveUrl(fn, args);

  useEffect(() => {
    let cancelled = false;
    setData(undefined);

    const doFetch = async () => {
      try {
        const result = await shineApi.request(url);
        if (!cancelled) setData(result);
      } catch (err: any) {
        console.warn("[SHINE] useQuery error:", err?.message);
        if (!cancelled) setData(null);
      }
    };
    doFetch();

    return () => { cancelled = true; };
  }, [url]);

  return data;
}

/**
 * useMutation — mirrors Convex's mutation hook.
 * Returns a function that, when called, sends a request to the API.
 */
export function useMutation(fn: ShimFn): (...args: any[]) => Promise<any> {
  const mutate = useCallback(
    async (...callArgs: any[]) => {
      const args = callArgs[0] || {};
      const url = resolveUrl(fn, args);
      const body = getBody(fn, args);

      if (fn._method === "DELETE") {
        return shineApi.request(url, { method: "DELETE" });
      } else if (fn._method === "PUT") {
        return shineApi.request(url, { method: "PUT", body });
      } else if (fn._method === "PATCH") {
        return shineApi.request(url, { method: "PUT", body });
      } else {
        return shineApi.request(url, { method: "POST", body });
      }
    },
    [fn],
  );

  return mutate;
}

/**
 * useAction — same as useMutation for our purposes.
 */
export function useAction(fn: ShimFn): (...args: any[]) => Promise<any> {
  return useMutation(fn);
}

/**
 * ConvexReactClient stub
 */
export class ConvexReactClient {
  constructor(_url: string) {}
}
