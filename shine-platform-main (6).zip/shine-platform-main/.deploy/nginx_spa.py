"""Patch the shine-web nginx container to add SPA try_files fallback."""
import subprocess

conf_path = "/etc/nginx/conf.d/default.conf"
with open(conf_path) as f:
    conf = f.read()

old_loc = """location / {
        root   /usr/share/nginx/html;
        index  index.html index.htm;
    }"""

new_loc = """location / {
        root   /usr/share/nginx/html;
        index  index.html index.htm;
        try_files $uri $uri/ /index.html;
    }"""

if "try_files" in conf:
    print("ALREADY_FIXED")
else:
    if old_loc in conf:
        with open(conf_path, "w") as f:
            f.write(conf.replace(old_loc, new_loc))
        print("PATCHED")
    else:
        print("PATTERN_NOT_FOUND")
        print(conf[:400])

r = subprocess.run(["nginx", "-t"], capture_output=True, text=True)
out = (r.stdout or r.stderr or "").strip()
print("NGINX_TEST:", out.splitlines()[-1] if out else str(r.returncode))
if r.returncode == 0:
    subprocess.run(["nginx", "-s", "reload"], capture_output=True, text=True)
    print("RELOADED")
