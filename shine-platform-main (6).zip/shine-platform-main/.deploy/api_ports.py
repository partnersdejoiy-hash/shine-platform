import io

path = "/opt/shine/docker-compose.yml"
with io.open(path, "r", encoding="utf-8") as f:
    src = f.read()

old = "    expose: [\"3001\"]"
new = "    expose: [\"3001\"]\n    ports:\n      - \"127.0.0.1:3001:3001\""

if old not in src:
    print("ANCHOR NOT FOUND")
    raise SystemExit(1)

src = src.replace(old, new, 1)
with io.open(path, "w", encoding="utf-8") as f:
    f.write(src)
print("COMPOSE_PATCHED")
