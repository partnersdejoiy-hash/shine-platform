"""Final login test against POST /api/auth/login (global prefix is 'api')."""
import json
import subprocess

ENV_PATH = "/opt/shine/.env"


def get(key):
    with open(ENV_PATH) as f:
        for line in f:
            if line.startswith(key + "="):
                return line.split("=", 1)[1].strip()
    return None


email = get("SUPER_ADMIN_EMAIL") or "deepak.sharma@dejoiy.com"
pw = get("SUPER_ADMIN_PASSWORD")
body = json.dumps({"email": email, "password": pw, "remember": True})

cmd = [
    "docker", "compose", "-f", "/opt/shine/docker-compose.yml",
    "exec", "-T", "api", "wget", "-S", "-O", "-",
    "--header=Content-Type: application/json",
    "--header=Accept: application/json",
    f"--post-data={body}",
    "http://localhost:3001/api/auth/login",
]
r = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
out = (r.stdout or "").strip()
try:
    data = json.loads(out)
    tok = data.get("accessToken") or data.get("token")
    user = data.get("user", {})
    print(f"LOGIN_OK email={user.get('email')} role={user.get('role')} token_issued={bool(tok)}")
except Exception:
    print("EXIT:", r.returncode)
    print("STDOUT:", out[:400])
    print("STDERR:", (r.stderr or "")[:500])
