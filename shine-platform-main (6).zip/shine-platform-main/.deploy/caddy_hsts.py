import re

p = "/etc/caddy/Caddyfile"
src = open(p).read()

old = "app.shine.dejoiy.com {\n\tencode gzip zstd\n\treverse_proxy 127.0.0.1:8090 {\n\t\tflush_interval -1\n\t}\n}"
new = "app.shine.dejoiy.com {\n\tencode gzip zstd\n\t# HSTS: force browsers to always use HTTPS\n\theader Strict-Transport-Security \"max-age=31536000\"\n\treverse_proxy 127.0.0.1:8090 {\n\t\tflush_interval -1\n\t}\n}"

if old in src:
    open(p, "w").write(src.replace(old, new, 1))
    print("HSTS_ADDED")
elif 'Strict-Transport-Security' in src and 'app.shine.dejoiy.com' in src:
    print("HSTS_ALREADY")
else:
    print("BLOCK_NOT_FOUND")
