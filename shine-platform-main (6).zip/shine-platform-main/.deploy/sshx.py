"""Paramiko SSH helper for deploying SHINE to the user's server.

Usage:
  SSHPASS='...' python3 sshx.py 'remote command'
  SSHPASS='...' python3 sshx.py put /local/path /remote/path
  SSHPASS='...' python3 sshx.py get /remote/path /local/path
  SSHPASS='...' python3 sshx.py put-buffer <remote_path>   (reads file content from stdin)
"""
import os
import sys

import paramiko

HOST = os.environ.get("SSHHOST", "178.104.228.157")
USER = os.environ.get("SSHUSER", "root")
PWD = os.environ["SSHPASS"]


def connect():
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        HOST,
        username=USER,
        password=PWD,
        timeout=20,
        banner_timeout=20,
        auth_timeout=20,
    )
    return client


def run(client, cmd, timeout=600):
    stdin, stdout, stderr = client.exec_command(cmd, timeout=timeout)
    out = stdout.read().decode(errors="replace")
    err = stderr.read().decode(errors="replace")
    rc = stdout.channel.recv_exit_status()
    return rc, out, err


def main():
    if len(sys.argv) < 2:
        print("usage: sshx.py <cmd> | put <local> <remote> | get <remote> <local> | put-buffer <remote>")
        sys.exit(2)
    mode = sys.argv[1]

    if mode == "put":
        client = connect()
        sftp = client.open_sftp()
        local, remote = sys.argv[2], sys.argv[3]
        sftp.put(local, remote)
        sftp.close()
        client.close()
        print(f"UPLOADED {local} -> {remote}")
        sys.exit(0)

    if mode == "get":
        client = connect()
        sftp = client.open_sftp()
        remote, local = sys.argv[2], sys.argv[3]
        sftp.get(remote, local)
        sftp.close()
        client.close()
        print(f"DOWNLOADED {remote} -> {local}")
        sys.exit(0)

    if mode == "put-buffer":
        client = connect()
        sftp = client.open_sftp()
        remote = sys.argv[2]
        data = sys.stdin.buffer.read()
        with sftp.file(remote, "wb") as f:
            f.write(data)
        sftp.close()
        client.close()
        print(f"WROTE {len(data)} bytes -> {remote}")
        sys.exit(0)

    # default: run a command
    cmd = " ".join(sys.argv[1:])
    client = connect()
    try:
        rc, out, err = run(client, cmd)
        if out:
            print(out.rstrip())
        if err:
            print("STDERR:", err.rstrip())
        print(f"RC: {rc}")
        sys.exit(0 if rc == 0 else 1)
    finally:
        client.close()


if __name__ == "__main__":
    main()
