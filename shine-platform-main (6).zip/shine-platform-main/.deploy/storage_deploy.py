import io
import subprocess
import sys
import time

SSH = ["python3", "/tmp/sshx.py"]
# sshx.py needs to exist on the remote host; we run from a local wrapper instead.

def run_local(cmd, timeout=120):
    print(f"$ {cmd[:120]}")
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
    out = (r.stdout + r.stderr).strip()
    if out:
        print(out[-1500:])
    return r.returncode, out

# 0) Push freshly built dist to the server workspace
code, _ = run_local("SSHPASS='Jaymaakaali@321' python3 .deploy/sshx.py 'mkdir -p /opt/shine/server/dist/storage'")
code, _ = run_local("SSHPASS='Jaymaakaali@321' python3 .deploy/sshx.py put server/dist/storage/storage.controller.js /opt/shine/server/dist/storage/storage.controller.js")
code, _ = run_local("SSHPASS='Jaymaakaali@321' python3 .deploy/sshx.py put server/dist/storage/storage.module.js /opt/shine/server/dist/storage/storage.module.js")
code, _ = run_local("SSHPASS='Jaymaakaali@321' python3 .deploy/sshx.py put server/dist/storage/minio.service.js /opt/shine/server/dist/storage/minio.service.js")
code, _ = run_local("SSHPASS='Jaymaakaali@321' python3 .deploy/sshx.py put server/dist/app.module.js /opt/shine/server/dist/app.module.js")
print("--- dist pushed ---")

# 1) Patch compose to publish API port 127.0.0.1:3001
code, _ = run_local("SSHPASS='Jaymaakaali@321' python3 .deploy/sshx.py put-buffer /tmp/api_ports.py < .deploy/api_ports.py")
code, _ = run_local("SSHPASS='Jaymaakaali@321' python3 .deploy/sshx.py 'python3 /tmp/api_ports.py'")
print("--- compose patched ---")

# 2) Recreate API container (new port mapping) with the existing image
code, out = run_local(
    "SSHPASS='Jaymaakaali@321' python3 .deploy/sshx.py 'cd /opt/shine && docker compose up -d api 2>&1 | tail -5'",
    timeout=150,
)
print("--- api recreated ---")

# 3) Copy freshly built dist into the container (new storage controller)
code, out = run_local(
    "SSHPASS='Jaymaakaali@321' python3 .deploy/sshx.py 'for f in storage.controller.js storage.module.js minio.service.js; do docker cp /opt/shine/server/dist/storage/$f shine-api-1:/app/dist/storage/$f; done; docker cp /opt/shine/server/dist/app.module.js shine-api-1:/app/dist/app.module.js 2>/dev/null; docker restart shine-api-1 >/dev/null 2>&1; sleep 6; docker exec shine-api-1 sh -c \"ls /app/dist/storage\"'",
    timeout=90,
)
print("--- dist copied + restarted ---")

# 4) Caddy: add /api/* -> 127.0.0.1:3001 on app.shine.dejoiy.com + meet.dejoiy.com
code, out = run_local("SSHPASS='Jaymaakaali@321' python3 .deploy/sshx.py 'cat /etc/caddy/Caddyfile'")
caddy = out
print("--- caddy read ---")

app_block_old = """app.shine.dejoiy.com {
\tencode gzip zstd
\t# HSTS: force browsers to always use HTTPS
\theader Strict-Transport-Security \"max-age=31536000\"
\treverse_proxy 127.0.0.1:8090 {
\t\tflush_interval -1
\t}
}"""

app_block_new = """app.shine.dejoiy.com {
\tencode gzip zstd
\t# HSTS: force browsers to always use HTTPS
\theader Strict-Transport-Security \"max-age=31536000\"
\thandle /api/* {
\t\treverse_proxy 127.0.0.1:3001 {
\t\t\tflush_interval -1
\t\t}
\t}
\thandle {
\t\treverse_proxy 127.0.0.1:8090 {
\t\t\tflush_interval -1
\t\t}
\t}
}"""

meet_block_old = """meet.dejoiy.com {
\tencode gzip zstd
\theader Strict-Transport-Security \"max-age=31536000\"
\treverse_proxy 127.0.0.1:8090 {
\t\tflush_interval -1
\t}
}"""

meet_block_new = """meet.dejoiy.com {
\tencode gzip zstd
\theader Strict-Transport-Security \"max-age=31536000\"
\thandle /api/* {
\t\treverse_proxy 127.0.0.1:3001 {
\t\t\tflush_interval -1
\t\t}
\t}
\thandle {
\t\treverse_proxy 127.0.0.1:8090 {
\t\t\tflush_interval -1
\t\t}
\t}
}"""

changed = 0
if app_block_old in caddy:
    caddy = caddy.replace(app_block_old, app_block_new, 1)
    changed += 1
    print("app block updated")
else:
    print("WARN app block not matched")

if meet_block_old in caddy:
    caddy = caddy.replace(meet_block_old, meet_block_new, 1)
    changed += 1
    print("meet block updated")
else:
    print("WARN meet block not matched")

if changed == 0:
    print("Nothing changed — abort")
    sys.exit(1)

with io.open("/tmp/caddy_new", "w", encoding="utf-8") as f:
    f.write(caddy)

code, _ = run_local("SSHPASS='Jaymaakaali@321' python3 .deploy/sshx.py put /tmp/caddy_new /etc/caddy/Caddyfile")
code, out = run_local(
    "SSHPASS='Jaymaakaali@321' python3 .deploy/sshx.py 'caddy validate --config /etc/caddy/Caddyfile 2>&1 | tail -2; systemctl reload caddy && echo CADDY_RELOADED'",
    timeout=60,
)
print("--- caddy done ---")

time.sleep(3)
code, out = run_local(
    "echo ===API_HEALTH===; curl -s -o /dev/null -w 'health:%{http_code}\\n' https://app.shine.dejoiy.com/api/health",
    timeout=45,
)
print(out)
print("DONE")
