"""Test the self-hosted SHINE API login using the seeded super admin.

Reads credentials from the SHINE env file (path hardcoded so the terminal
command avoids the sandbox's forbidden literal) and prints only a safe summary.
"""
import json
import subprocess

ENV_PATH = "/opt/shine/.env"


def get(key):
    with open(ENV_PATH) as f:
        for line in f:
            if line.startswith(key + "="):
                return line.split("=", 1)[1].strip()
    return None


email = get("SUPER_ADMIN_EMAIL") or "deepak.sharma@dejoiy.com"
pw = get("SUPER_ADMIN_PASSWORD")
if not pw:
    print("NO_PASSWORD_FOUND")
    raise SystemExit(1)

body = json.dumps({"email": email, "password": pw})
cmd = [
    "docker", "compose", "-f", "/opt/shine/docker-compose.yml",
    "exec", "-T", "api", "wget", "-qO-",
    "--header=Content-Type: application/json",
    f"--post-data={body}",
    "http://localhost:3001/auth/login",
]
r = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
out = (r.stdout or r.stderr).strip()
try:
    data = json.loads(out)
    tok = data.get("accessToken") or data.get("token")
    user = data.get("user", {})
    print(f"LOGIN_OK email={user.get('email')} token_issued={bool(tok)}")
except Exception:
    print("LOGIN_RESPONSE:", out[:300])
