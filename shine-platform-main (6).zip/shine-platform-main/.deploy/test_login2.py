"""Verbose login test — prints response status line, body, and wget exit code."""
import json
import subprocess

ENV_PATH = "/opt/shine/.env"


def get(key):
    with open(ENV_PATH) as f:
        for line in f:
            if line.startswith(key + "="):
                return line.split("=", 1)[1].strip()
    return None


email = get("SUPER_ADMIN_EMAIL") or "deepak.sharma@dejoiy.com"
pw = get("SUPER_ADMIN_PASSWORD")
body = json.dumps({"email": email, "password": pw, "remember": True})

cmd = [
    "docker", "compose", "-f", "/opt/shine/docker-compose.yml",
    "exec", "-T", "api", "wget", "-S", "-O", "-",
    "--header=Content-Type: application/json",
    "--header=Accept: application/json",
    f"--post-data={body}",
    "http://localhost:3001/auth/login",
]
r = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
print("EXIT:", r.returncode)
print("STDOUT:", (r.stdout or "")[:400])
print("STDERR:", (r.stderr or "")[:600])
