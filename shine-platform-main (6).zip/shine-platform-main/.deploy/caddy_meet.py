"""Add meet.dejoiy.com vhost to the server Caddyfile and reload Caddy."""
import subprocess
import sys

path = "/etc/caddy/Caddyfile"
try:
    with open(path) as f:
        content = f.read()
except FileNotFoundError:
    print("CADDYFILE_NOT_FOUND")
    sys.exit(1)

block = """
# SHINE Standalone Meeting site (meet.dejoiy.com)
meet.dejoiy.com {
\tencode gzip zstd
\theader Strict-Transport-Security "max-age=31536000"
\treverse_proxy 127.0.0.1:8090 {
\t\tflush_interval -1
\t}
}
"""

if "meet.dejoiy.com" in content:
    print("ALREADY_PRESENT")
else:
    with open(path, "a") as f:
        f.write(block)
    print("ADDED")

r = subprocess.run(["caddy", "validate", "--config", path], capture_output=True, text=True)
out = (r.stdout or r.stderr or "").strip()
print("VALIDATE:", out.splitlines()[-1] if out else str(r.returncode))
if r.returncode == 0:
    r2 = subprocess.run(["systemctl", "reload", "caddy"], capture_output=True, text=True)
    print("RELOAD:", "OK" if r2.returncode == 0 else (r2.stderr or r2.stdout or "?").strip()[-300:])
